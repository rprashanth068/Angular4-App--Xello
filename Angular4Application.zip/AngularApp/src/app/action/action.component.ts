import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.css']
})
export class ActionComponent implements OnInit {
  private isGreenVisible = false;
  private isBlueVisible = false;
  private selectedAction: string;

  constructor() { }

  @HostListener('window:click')
  onclick() {
    this.closeAllTooltips();
  }

  @HostListener('window:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent) {
    if (e && e.keyCode === 27) {
      this.closeAllTooltips();
    }
  }

  ngOnInit() {
  }

  Click(e?: string) {
    this.selectedAction = e;
    if (e === 'test') {
      this.isGreenVisible = true;
    } else {
      this.isGreenVisible = false;
    }
    this.isBlueVisible = !this.isGreenVisible;
  }

  closeAllTooltips() {
    this.isBlueVisible = false;
    this.isGreenVisible = false;
  }
}
