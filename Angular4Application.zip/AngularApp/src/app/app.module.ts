import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { TooltipComponent } from './tooltip/tooltip.component';
import { ActionComponent } from './action/action.component';

@NgModule({
  declarations: [
    AppComponent,
    TooltipComponent,
    ActionComponent
  ],
  imports: [
    RouterModule.forRoot([
      { path: 'action', component: ActionComponent },
    ]),
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
